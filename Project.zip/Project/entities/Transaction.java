package com.tns.banking.entities;

import java.time.LocalDateTime;

public class Transaction {
	private int Transaction_id;
	private int Account_Id;
	private String Type;
	private double Amount;
	private LocalDateTime timestamp;
	public Transaction(int transaction_id, int account_Id, String type, double amount, LocalDateTime timestamp) {
		super();
		Transaction_id = transaction_id;
		Account_Id = account_Id;
		Type = type;
		Amount = amount;
		this.timestamp = timestamp;
	}
	public int getTransaction_id() {
		return Transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		Transaction_id = transaction_id;
	}
	public int getAccount_Id() {
		return Account_Id;
	}
	public void setAccount_Id(int account_Id) {
		Account_Id = account_Id;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public double getAmount() {
		return Amount;
	}
	public void setAmount(double amount) {
		Amount = amount;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	@Override
	public String toString() {
		return "Transaction [Transaction_id=" + Transaction_id + ", Account_Id=" + Account_Id + ", Type=" + Type
				+ ", Amount=" + Amount + ", timestamp=" + timestamp + ", getTransaction_id()=" + getTransaction_id()
				+ ", getAccount_Id()=" + getAccount_Id() + ", getType()=" + getType() + ", getAmount()=" + getAmount()
				+ ", getTimestamp()=" + getTimestamp() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	
	

}
