package com.tns.banking.entities;

public class Beneficiary {
	public Beneficiary(int beneficiary_id, int customer_id, String name, String accountNumber, String bankdetails) {
		super();
		Beneficiary_id = beneficiary_id;
		Customer_id = customer_id;
		Name = name;
		AccountNumber = accountNumber;
		Bankdetails = bankdetails;
	}
	private int Beneficiary_id;
	private int Customer_id;
	private String Name;
	private String AccountNumber;
	private String Bankdetails;
	@Override
	public String toString() {
		return "Beneficiary [Beneficiary_id=" + Beneficiary_id + ", Customer_id=" + Customer_id + ", Name=" + Name
				+ ", AccountNumber=" + AccountNumber + ", Bankdetails=" + Bankdetails + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	public int getBeneficiary_id() {
		return Beneficiary_id;
	}
	public void setBeneficiary_id(int beneficiary_id) {
		Beneficiary_id = beneficiary_id;
	}
	public int getCustomer_id() {
		return Customer_id;
	}
	public void setCustomer_id(int customer_id) {
		Customer_id = customer_id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAccountNumber() {
		return AccountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		AccountNumber = accountNumber;
	}
	public String getBankdetails() {
		return Bankdetails;
	}
	public void setBankdetails(String bankdetails) {
		Bankdetails = bankdetails;
	}

	

}
