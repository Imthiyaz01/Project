package com.tns.banking.entities;

public class Account {
	private int Account_Id;
	private int Customer_Id;
	private String Type;
	private double Balance;
	
	public Account(int account_Id, int customer_Id, String type, double balance) {
		super();
		Account_Id = account_Id;
		Customer_Id = customer_Id;
		Type = type;
		Balance = balance;
	}
	public int getAccount_Id() {
		return Account_Id;
	}
	public void setAccount_Id(int account_Id) {
		Account_Id = account_Id;
	}
	public int getCustomer_Id() {
		return Customer_Id;
	}
	public void setCustomer_Id(int customer_Id) {
		Customer_Id = customer_Id;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	@Override
	public String toString() {
		return "Account [Account_Id=" + Account_Id + ", Customer_Id=" + Customer_Id + ", Type=" + Type + ", Balance="
				+ Balance + "]";
	}

}
