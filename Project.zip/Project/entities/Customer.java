package com.tns.banking.entities;

public class Customer {
	public Customer(int customer_Id, String name, String address, String contact) {
		super();
		Customer_Id = customer_Id;
		Name = name;
		Address = address;
		Contact = contact;
	}
	private int Customer_Id;
	private String Name;
	private String Address;
	private String Contact;
	
	public int getCustomer_Id() {
		return Customer_Id;
	}
	public void setCustomer_Id(int customer_Id) {
		Customer_Id = customer_Id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getAddress() {
		return Address;
	}
	public void setAddress(String address) {
		Address = address;
	}
	public String getContact() {
		return Contact;
	}
	public void setContact(String contact) {
		Contact = contact;
	}
	@Override
	public String toString() {
		return "Customer [Customer_Id=" + Customer_Id + ", Name=" + Name + ", Address=" + Address + ", Contact="
				+ Contact + "]";
	}
	
	

}
