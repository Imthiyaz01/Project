package com.tns.banking.services;

import java.util.Collection;
import java.util.List;

import com.tns.banking.entities.Account;
import com.tns.banking.entities.Beneficiary;
import com.tns.banking.entities.Customer;
import com.tns.banking.entities.Transaction;

public class BankingServiceImpl implements BankingService {

	@Override
	public void addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addAccount(Account account) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addBeneficiary(Beneficiary beneficiary) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Customer findCustomerById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Account findAccountById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Transaction findTransactionById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Beneficiary findBeneficiaryById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Account> getAllAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Collection<Beneficiary> getAllBeneficiaries() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> getAccountsByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getTransactionsByAccountId(int accountId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Beneficiary> getBeneficiariesByCustomerId(int customerId) {
		// TODO Auto-generated method stub
		return null;
	}

}
